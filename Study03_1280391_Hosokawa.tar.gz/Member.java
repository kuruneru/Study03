interface Member {
    /* キャラクターごとにスキルを実装させる */
    public void skill(Character c);
}