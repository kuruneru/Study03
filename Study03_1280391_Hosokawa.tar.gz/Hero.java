public class Hero extends Ally{

    /* コンストラクタ */
    public Hero(String name, int hp, int atk) {
        super(name, hp, atk);
    }

}